package com.xcx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xcx.entity.BigType;
import com.xcx.entity.WxUserInfo;

/*
* 微信用户 Service接口
* */
public interface IWxUserInfoService extends IService<WxUserInfo> {

}
