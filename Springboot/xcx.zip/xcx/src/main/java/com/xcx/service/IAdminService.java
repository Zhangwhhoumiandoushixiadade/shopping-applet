package com.xcx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xcx.entity.Admin;

/**
* 管理员账号 Service接口
* */
public interface IAdminService extends IService<Admin> {

}
