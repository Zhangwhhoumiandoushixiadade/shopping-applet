package com.xcx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xcx.entity.BigType;
import com.xcx.entity.ProductSwiperImage;

/*
* 商品轮播图片接口
* */
public interface IProductSwiperImageService extends IService<ProductSwiperImage> {

}
