package com.xcx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xcx.entity.ProductSwiperImage;


/*
* 商品轮播图片 Map接口
* */
public interface ProductSwiperImageMapper extends BaseMapper<ProductSwiperImage> {

}
