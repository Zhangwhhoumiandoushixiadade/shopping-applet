package com.xcx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xcx.entity.BigType;
import com.xcx.entity.OrderDetail;

/*
* 订单细节 Service接口
* */
public interface IOrderDetailService extends IService<OrderDetail> {

}
