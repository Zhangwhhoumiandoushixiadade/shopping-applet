package com.xcx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xcx.entity.BigType;
import com.xcx.entity.OrderDetail;


/*
* 订单细节 Map接口
* */
public interface OrderDetailMapper extends BaseMapper<OrderDetail> {

}
