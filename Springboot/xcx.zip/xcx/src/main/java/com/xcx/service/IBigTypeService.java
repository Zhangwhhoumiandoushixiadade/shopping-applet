package com.xcx.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xcx.entity.BigType;

/*
* 微信用户 Service接口
* */
public interface IBigTypeService extends IService<BigType> {

}
