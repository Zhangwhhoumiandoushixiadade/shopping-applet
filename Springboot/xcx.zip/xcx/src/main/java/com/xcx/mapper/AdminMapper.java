package com.xcx.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xcx.entity.Admin;


/*
* 管理员账号 Map接口
* */
public interface AdminMapper extends BaseMapper<Admin> {

}
